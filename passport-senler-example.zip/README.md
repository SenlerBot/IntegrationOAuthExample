# Пример использования Senler OAuth с Passport.js

Простой пример интеграции Senler OAuth через Passport.js с TypeScript и Express.

## Установка

```bash
npm install
```

## Настройка

1. Скопируйте файл конфигурации:
```bash
cp env.example .env
```

2. Отредактируйте `.env` с вашими данными от Senler:
```env
SENLER_CLIENT_ID=ваш_client_id
SENLER_CLIENT_SECRET=ваш_client_secret
SENLER_CALLBACK_URL=http://localhost:3000/auth/senler/callback
SESSION_SECRET=ваш_случайный_ключ_сессии
PORT=3000
```

3. Получите данные приложения в [панели разработчика Senler](https://senler.ru/):
   - Создайте приложение
   - Скопируйте `Client ID` и `Client Secret`
   - Укажите Callback URL: `http://localhost:3000/auth/senler/callback`

## Запуск

```bash
# Разработка
npm run dev

# Продакшен
npm start
```

Приложение будет доступно по адресу: http://localhost:3000

## Основной код

```typescript
import express from 'express';
import session from 'express-session';
import passport from 'passport';
import { SenlerStrategy, SenlerChannel } from 'passport-senler';
import { SenlerApiClientV2 } from 'senler-sdk';

const app = express();

// Сессии
app.use(session({
  secret: process.env.SESSION_SECRET!,
  resave: false,
  saveUninitialized: false,
  cookie: { maxAge: 24 * 60 * 60 * 1000 } // 24 часа
}));

// Passport стратегия
passport.use(new SenlerStrategy({
  clientID: process.env.SENLER_CLIENT_ID!,
  clientSecret: process.env.SENLER_CLIENT_SECRET!,
  callbackURL: process.env.SENLER_CALLBACK_URL!,
}, (accessToken, refreshToken, profile, done) => {
  return done(null, { accessToken, refreshToken, profile });
}));

app.use(passport.initialize());

// Аутентификация
app.get('/auth/senler', passport.authenticate('senler'));

app.get('/auth/senler/callback',
  passport.authenticate('senler', { failureRedirect: '/', session: false }),
  (req, res) => {
    const user = req.user as SenlerChannel;
    
    // Сохраняем пользователя в сессии
    req.session.user = user;
    res.redirect('/');
  }
);

// Главная страница с данными
app.get('/', async (req, res) => {
  const user = req.session.user;
  
  if (!user?.accessToken || !user?.groupId) {
    return res.send('<a href="/auth/senler">Войти через Senler</a>');
  }

  try {
    // Работа с Senler API
    const senlerClient = new SenlerApiClientV2({
      apiConfig: {
        accessToken: user.accessToken,
        vkGroupId: Number(user.groupId)
      }
    });

    const subscribers = await senlerClient.subscribers.get({ count: 10 });
    
    res.json({
      groupId: user.groupId,
      subscribersCount: subscribers.items.length,
      subscribers: subscribers.items
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.listen(3000);
```

## Важные моменты

- **Сессии**: Используйте `session: false` в passport.authenticate и сохраняйте данные в `req.session`
- **Group ID**: Автоматически получается из `SenlerChannel.groupId`
- **Токены**: Храните в сессии, а не в URL параметрах
- **Продакшен**: Используйте HTTPS для Callback URL

## Типы TypeScript

```typescript
interface SenlerChannel {
  accessToken: string;
  groupId?: string;
}

declare module 'express-session' {
  interface SessionData {
    user?: SenlerChannel;
  }
}
```

## Зависимости

- [passport-senler](https://github.com/SenlerBot/passport-senler) - OAuth стратегия
- [senler-sdk](https://github.com/SenlerBot/senler-sdk) - SDK для API 