import express, { Request, Response, NextFunction, Application } from 'express';
import session from 'express-session';
import passport from 'passport';
import dotenv from 'dotenv';
import { SenlerStrategy, SenlerChannel } from 'passport-senler';
import { SenlerApiClientV2 } from 'senler-sdk';

// Расширение типов сессии
declare module 'express-session' {
  interface SessionData {
    user?: SenlerChannel;
  }
}

// Загрузка переменных окружения
dotenv.config();

const app: Application = express();
const PORT: number = Number(process.env.PORT) || 3000;

// Middleware для обработки JSON
app.use(express.json());

// Конфигурация сессий
app.use(session({
  secret: process.env.SESSION_SECRET || 'senler-dashboard-secret-key-' + Math.random().toString(36),
  resave: false,
  saveUninitialized: false,
  cookie: {
    secure: process.env.NODE_ENV === 'production', // HTTPS только в продакшене
    httpOnly: true, // Защита от XSS
    maxAge: 24 * 60 * 60 * 1000, // 24 часа
  }
}));

// Конфигурация стратегии Passport для Senler

passport.use(
  new SenlerStrategy({
    clientID: process.env.SENLER_CLIENT_ID!,
    clientSecret: process.env.SENLER_CLIENT_SECRET!,
    callbackURL: process.env.SENLER_CALLBACK_URL || `http://localhost:${PORT}/auth/senler/callback`,
  }, (accessToken: string, refreshToken: string, profile: any, done: any) => {
    console.log('✅ Callback от Senler: токен получен');
    return done(null, { accessToken, refreshToken, profile });
  }) as any
);

// Инициализация Passport
app.use(passport.initialize());

// Функция для генерации минимального HTML
const generateHTML = (title: string, content: string): string => {
  return `<!DOCTYPE html>
<html><head><meta charset="UTF-8"><title>${title}</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:Arial,sans-serif;background:#fff;padding:20px;color:#333}
.container{max-width:600px;margin:0 auto;text-align:center}
.logo{font-size:1.5rem;font-weight:bold;color:#428BCA;margin-bottom:20px}
.btn{background:#428BCA;color:#fff;border:none;padding:10px 20px;border-radius:4px;text-decoration:none;display:inline-block}
.btn:hover{background:#357ebd}
.stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(100px,1fr));gap:10px;margin:20px 0}
.stat{background:#f5f5f5;padding:10px;border-radius:4px}
.stat-number{font-size:1.2rem;font-weight:bold;color:#428BCA}
.stat-label{font-size:0.8rem;color:#666}
.table{background:#f5f5f5;border-radius:4px;margin-top:20px}
.table-header{background:#428BCA;color:#fff;padding:8px;font-weight:bold}
.table-row{padding:5px 8px;border-bottom:1px solid #ddd;display:grid;grid-template-columns:1fr 2fr 1fr;gap:5px}
.error{color:#d63384;background:#f8d7da;padding:8px;border-radius:4px;margin:10px 0}
.loading{color:#428BCA;margin:20px 0}
</style></head>
<body><div class="container"><div class="logo">Senler</div>${content}</div></body></html>`
};

// Главная страница
app.get('/', async (req: Request, res: Response): Promise<void> => {
  // Читаем данные из сессии
  const user = req.session.user;
  const token = user?.accessToken;
  const groupId = user?.groupId;
  const error = req.query.error as string;
  const errorDetails = req.query.details as string;
  const errorDescription = req.query.description as string;

  console.log('📄 Главная страница: Token=', token ? '✓' : '✗', 'GroupID=', groupId || '✗');

    if (token && groupId) {
    try {
      // Создание клиента Senler SDK
      const senlerClient = new SenlerApiClientV2({
        apiConfig: {
          accessToken: token,
          groupId: Number(groupId)
        }
      });
      
      // Пытаемся получить подписчиков
      const subscribersResponse = await senlerClient.subscribers.get({
        count: 30
      });

      const subscribers = subscribersResponse?.items || [];
      const total = subscribers.length;
      const active = subscribers.filter((s: any) => s.is_active).length;
      const inactive = total - active;

      console.log(`✅ Загружено ${total} подписчиков`);

      const content = `
        <h2>✅ Успешная авторизация</h2>
        <div class="stats">
          <div class="stat">
            <div class="stat-number">${groupId}</div>
            <div class="stat-label">Идентификатор группы</div>
          </div>
        </div>
        <div style="margin-top: 20px; padding: 10px; background: #f5f5f5; border-radius: 4px; text-align: left;">
          <strong>Полученные данные:</strong><br>
          • Токен доступа: ${token.substring(0, 15)}...<br>
          • Group ID: ${groupId}<br>
          • Время авторизации: ${new Date().toLocaleString('ru-RU')}
        </div>

        <h3 style="margin-top: 30px;">📊 Статистика подписчиков</h3>
        <div class="stats">
          <div class="stat">
            <div class="stat-number">${total}</div>
            <div class="stat-label">Всего</div>
          </div>
          <div class="stat">
            <div class="stat-number">${active}</div>
            <div class="stat-label">Активные</div>
          </div>
          <div class="stat">
            <div class="stat-number">${inactive}</div>
            <div class="stat-label">Неактивные</div>
          </div>
        </div>

        ${subscribers.length > 0 ? `
          <div class="table">
            <div class="table-header">Подписчики (первые 10)</div>
            ${subscribers.slice(0, 10).map((sub: any) => `
              <div class="table-row">
                <div>${sub.id || 'N/A'}</div>
                <div>${(sub.first_name || 'Неизвестно') + ' ' + (sub.last_name || '')}</div>
                <div>${sub.is_active ? '✅ Активен' : '❌ Неактивен'}</div>
              </div>
            `).join('')}
          </div>
        ` : '<p style="margin-top: 15px;">Подписчики не найдены</p>'}

        <a href="/logout" class="btn" style="margin-top: 20px;">Выйти</a>
      `;
      
      res.send(generateHTML('Senler Dashboard - Авторизован', content));

    } catch (error: any) {
      console.error('❌ Ошибка API:', error.message);
      
      // Показываем Group ID даже при ошибке загрузки статистики
      const errorContent = `
        <h2>✅ Успешная авторизация</h2>
        <div class="stats">
          <div class="stat">
            <div class="stat-number">${groupId}</div>
            <div class="stat-label">Идентификатор группы</div>
          </div>
        </div>
        <div style="margin-top: 20px; padding: 10px; background: #f5f5f5; border-radius: 4px; text-align: left;">
          <strong>Полученные данные:</strong><br>
          • Токен доступа: ${token.substring(0, 15)}...<br>
          • Group ID: ${groupId}<br>
          • Время авторизации: ${new Date().toLocaleString('ru-RU')}
        </div>

        <h3 style="margin-top: 30px;">❌ Ошибка от Senler API</h3>
        <div class="error">
          <strong>Не удалось загрузить данные подписчиков</strong><br>
          <strong>Ошибка:</strong> ${error.message}<br>
          ${error.response?.data ? `<br><strong>Детали от API:</strong><br><pre style="background: #fff; padding: 5px; border-radius: 3px; font-size: 0.8rem; text-align: left;">${JSON.stringify(error.response.data, null, 2)}</pre>` : ''}
          ${error.status || error.statusCode ? `<br><strong>HTTP статус:</strong> ${error.status || error.statusCode}` : ''}
        </div>
        <a href="/logout" class="btn" style="margin-top: 20px;">Попробовать снова</a>
      `;
      
      res.send(generateHTML('Senler Dashboard - Авторизован с ошибкой', errorContent));
    }
    } else if (token && !groupId) {
      // Есть токен, но нет group_id - ошибка аутентификации
      const errorContent = `
        <h2>❌ Неполные данные аутентификации</h2>
        <div class="error">
          <strong>Получен токен доступа, но отсутствует Group ID</strong><br>
          Это может произойти если:<br>
          • Group ID не найден ни в профиле пользователя, ни в callback параметрах<br>
          • Проблема с passport-senler библиотекой<br>
          • Senler не передал group_id в ответе OAuth<br>
          • Проверьте логи сервера для деталей поиска group_id
        </div>
        <a href="/logout" class="btn" style="margin-top: 20px;">Попробовать снова</a>
      `;
      res.send(generateHTML('Senler Dashboard - Ошибка данных', errorContent));
    } else {
    // Показываем страницу входа с детальными ошибками
    let errorHtml = '';
    
    if (error) {
      let errorMessage = 'Произошла ошибка при аутентификации';
      let troubleshooting = '';
      
      switch (error) {
        case 'auth_failed':
          errorMessage = 'Ошибка аутентификации Senler';
          troubleshooting = `
            <strong>Возможные причины:</strong><br>
            • Неверный Client ID или Client Secret<br>
            • Неправильный Callback URL<br>
            • Приложение не активировано в Senler<br>
            • Проблемы с разрешениями приложения
          `;
          break;
        case 'senler_error':
          errorMessage = 'Ошибка от Senler API';
          troubleshooting = `
            <strong>Детали от Senler:</strong><br>
            ${errorDetails ? `• Код ошибки: ${errorDetails}<br>` : ''}
            ${errorDescription ? `• Описание: ${errorDescription}<br>` : ''}
            <strong>Проверьте настройки приложения в панели Senler</strong>
          `;
          break;
        case 'no_token':
          errorMessage = 'Токен доступа не получен';
          troubleshooting = `
            <strong>Проблема:</strong><br>
            • Аутентификация прошла, но токен не был возвращен<br>
            • Возможно, проблема с passport-senler библиотекой<br>
            • Проверьте логи сервера для деталей
          `;
          break;
        case 'no_group_id':
          errorMessage = 'Group ID не получен';
          troubleshooting = `
            <strong>Проблема:</strong><br>
            • Аутентификация прошла, токен получен, но Group ID отсутствует<br>
            • Group ID не найден ни в профиле пользователя, ни в callback параметрах<br>
            • Senler не передал group_id в ответе OAuth<br>
            • Возможно, проблема с настройками приложения в Senler<br>
            • Проверьте логи сервера - должны быть видны детали поиска group_id
          `;
          break;
        default:
          errorMessage = `Неизвестная ошибка: ${error}`;
      }
      
      errorHtml = `
        <div class="error">
          <strong>${errorMessage}</strong><br>
          ${troubleshooting}
          ${errorDetails ? `<br><em>Детали: ${errorDetails}</em>` : ''}
        </div>
      `;
    }
    
    const content = `
      <p style="margin-bottom: 20px;">Для доступа к статистике необходимо авторизоваться через Senler</p>
      ${errorHtml}
      <a href="/auth/senler" class="btn">🔐 Войти через Senler</a>
      <div style="margin-top: 20px; font-size: 0.9rem; color: #666;">
        <strong>Отладочная информация:</strong><br>
        • Client ID: ${process.env.SENLER_CLIENT_ID ? '✅ Настроен' : '❌ Не настроен'}<br>
        • Client Secret: ${process.env.SENLER_CLIENT_SECRET ? '✅ Настроен' : '❌ Не настроен'}<br>
        • Callback URL: ${process.env.SENLER_CALLBACK_URL || `http://localhost:${PORT}/auth/senler/callback`}<br>
        • Group ID: Получается автоматически при аутентификации от Senler
      </div>
    `;
    res.send(generateHTML('Senler Dashboard - Вход', content));
  }
});

// Начало процесса аутентификации через Senler
app.get('/auth/senler', (req: Request, res: Response, next: NextFunction): void => {
  console.log('🚀 Запуск аутентификации Senler');
  passport.authenticate('senler')(req, res, next);
});

// Обработчик обратного вызова для Senler
app.get(
  '/auth/senler/callback',
  (req: Request, res: Response, next: NextFunction): void => {
    // Проверяем наличие ошибки в callback
    if (req.query.error) {
      console.error('❌ Ошибка callback:', req.query.error);
      return res.redirect(`/?error=senler_error&details=${encodeURIComponent(req.query.error as string)}&description=${encodeURIComponent(req.query.error_description as string || 'Неизвестная ошибка')}`);
    }
    
    next();
  },
  passport.authenticate('senler', {
    failureRedirect: '/auth/senler/error',
    session: false, // Отключаем сессии
  }),
  (req: Request & { user?: any }, res: Response): void => {
    const user = req.user as SenlerChannel;
    const accessToken = user?.accessToken;
    let groupId = user?.groupId;
    
    console.log('✅ Аутентификация завершена. Group ID:', groupId || 'НЕ НАЙДЕН');
    
    if (!accessToken) {
      console.error('❌ Токен доступа не найден');
      return res.redirect('/?error=no_token');
    }
    
    if (!groupId) {
      console.error('❌ Group ID не найден');
      return res.redirect('/?error=no_group_id');
    }
    
    // Сохраняем данные в сессии
    req.session.user = user;
    
    console.log('💾 Данные сохранены в сессии');
    
    // Перенаправляем на главную страницу без чувствительных данных в URL
    res.redirect('/');
  }
);

// Страница ошибки аутентификации с детальной информацией
app.get('/auth/senler/error', (req: Request, res: Response): void => {
  const errorDetails = req.query.error_description || req.query.error || 'Неизвестная ошибка';
  res.redirect(`/?error=auth_failed&details=${encodeURIComponent(errorDetails as string)}`);
});

// Роут для выхода из системы
app.get('/logout', (req: Request, res: Response): void => {
  req.session.destroy((err) => {
    if (err) {
      console.error('❌ Ошибка выхода:', err);
      res.redirect('/?error=logout_error');
    } else {
      res.redirect('/');
    }
  });
});

// Обработка ошибок
app.use((err: Error, _req: Request, res: Response, _next: NextFunction): void => {
  console.error(err.stack);
  res.status(500).json({
    error: 'Внутренняя ошибка сервера',
    message: err.message
  });
});

// Запуск сервера
app.listen(PORT, (): void => {
  console.log(`🚀 Сервер запущен на http://localhost:${PORT}`);
  
  if (!process.env.SENLER_CLIENT_ID || !process.env.SENLER_CLIENT_SECRET) {
    console.warn('⚠️  Переменные SENLER_CLIENT_ID и SENLER_CLIENT_SECRET не установлены');
  }
});

export default app; 